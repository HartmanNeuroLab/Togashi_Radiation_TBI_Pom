function circIndivData=dam_analyze_2019(o,selectedAnalysis,selectedGroup,list)
%DAM_ANALYZE_2019  Simplified version that just generates the (px, ri, rs)
%data without creating any figures
%
% o: dam data, as read by dam_load. 
% doprint: 1=print 0=don't print(default)
% wells: list of columns to be analyzed
% par: multiple parameters, obtained from dam_analyze_par. 
% also, all of dam_panels_par parameters are included.
% (enter dam_analyze_par to see the defaults.) 
%
% see also: dam_panels, dam_load
%
% examples:
% >> o=dam_load;
% >> dam_analyze(o,1) % analyze and print all flies
% >> dam_analyze(o,0,1:8) % just first 8 flies and don't print
% >> p=dam_analyze_par
%
% p = 
%
%          lopass: 4
%          hipass: 0
%        plotcols: {'acto'  'histo'  'auto'  'mesa'}
%    dam_hist_par: [1x1 struct]
%        truncate: []
%       peakRange: [16 32]
%        plotrows: 8
%        fontsize: 6
%      markersize: 4
%       mfl=30
% >> p.lopass=0;
% dam_analyze(o,1,1:32,p) % analyze flies 1:32, don't use lopas filter
%

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Jeffrey Hall Lab, Brandeis University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Jeff Hall Lab, Kalman Bldg, Brandeis Univ, Waltham MA 02454 USA %%
% Email: hall@brandeis.edu                                        %%
% Edited 2012 by Christopher G. Vecsey, Griffith Lab              %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (nargin<2)
  doprint=0;
end

% if nargin==2 && length(doprint)>1
%   wells=doprint;
%   doprint=0;
% end

wells=1:size(o.data,2);

par=dam_panels_par(selectedAnalysis);
  
if ~isempty(par.truncate)
  o=dam_truncate(o,par.truncate(1),par.truncate(2),'bins');
  par.truncate=[];
end

circIndivData={};
PX=zeros(1,length(wells));
RI=zeros(1,length(wells));
RS=zeros(1,length(wells));
for i=1:length(wells)
  % for each fly
  groupname=list{selectedGroup};
  [px,ri,rs]=dam_panels_2019(o,i,selectedAnalysis,par);
  
  if ~isempty(px) 
  PX(i)=px;
  RI(i)=ri;
  RS(i)=rs;
  end
 
end
  %Makes an object that has 3 arrays, one for each variable, then output
  %that object from dam_analyze for blah to combine groups into new object and export
circIndivData{1}=PX;
circIndivData{2}=RI;
circIndivData{3}=RS;