function [px,ri,rs]=acplot_2019(ac,x,in,peakrange)
%ACPLOT_2019 Just calculates px, ri, and rs values without plotting any graphs.
%
% ac: autocorrelation info (see autoco)
% x: lag 
% in: confidence interval
% peakrange: find peak btween peakrange(1) and peakrange(2)
% and compute rhythmicity index there.
% 
% see help rindex for an explanation of the output parameters. 

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Jeffrey Hall Lab, Brandeis University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Jeff Hall Lab, Kalman Bldg, Brandeis Univ, Waltham MA 02454 USA %%
% Email: hall@brandeis.edu                                        %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin>3 && ~isempty(peakrange)
  [ri,rs,px]=rindex_raw(ac,x,in,peakrange);

  px=px/2;
end
