function [px,ri,rs]=dam_panels_2019(o,wells,selectedAnalysis,par)
%DAM_PANELS_2019   This simplified version just runs autocorrelation for
%export in SCAMP.
%
% Inputs: 
% o - Variable with dam information (see dam_load).
% i - Number of wells (flies) within o that are to be analyzed.
%     If a list of wells, an average will be taken.
%     (default: all of the wells in o). 
%
% par: Block of parameters (as in par=dam_panels_par)
% (enter dam_panels_par to see the defaults).
% par.lopass: Cutoff (hours) for lo-pass filter 
% par.hipass: Cutoff (hours) for hi-pass filter
% (set par.lopass and par.hipass to 0 for no filtering)
% Panels available are: 
%     'auto'  - autocorrelation (see autoco)
%
% selectedAnalysis: which of the panels above have been chosen for graphing
% groupname: name of group whose data is being analyzed
% par.dam_hist_par: Histogram parameters (see dam_hist)
% par.peakRange: Range of rhythm (see mesaplot)
% par.mesaFunct, par.mesaOrder: see per_mesa. 
% par.cutoff: Actogram cutoff (see actogram).
% par.truncate: Time truncation, in bins (see dam_truncate)
%
% example: o=dam_load('E21');p=dam_panels_par;
%          p.lopass=0;dam_panels(o,1:8,1,1,p);

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Jeffrey Hall Lab, Brandeis University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Jeff Hall Lab, Kalman Bldg, Brandeis Univ, Waltham MA 02454 USA %%
% Email: hall@brandeis.edu                                        %%
% Edited 2012 by Christopher G. Vecsey, Leslie Griffith Lab       %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
px=[];
ri=[];
rs=[];

if nargin<4  %This gets called because only 6 arguments are provided in SCAMP
  par=dam_panels_par(selectedAnalysis);
end

if ~isempty (par.truncate)   %This does not get called in current arrangement
  o=dam_truncate(par.truncate(1),par.truncate(2),'bins');
end

f=o.f(:,wells);
x=o.x;
meanf=mean(f,2);

if par.lopass>0 || par.hipass>0
  filterf=butt_filter(meanf,par.lopass/o.int*60,par.hipass/o.int*60);
else
  filterf=meanf;
end

% Just runs autocorrelation analysis to generate px, ri, and rs values.

    [ac,xx,ci]=autoco(filterf,60/o.int);
    [px,ri,rs]=acplot_2019(ac,xx,ci,(par.acPeak-1)*24+par.peakRange);

