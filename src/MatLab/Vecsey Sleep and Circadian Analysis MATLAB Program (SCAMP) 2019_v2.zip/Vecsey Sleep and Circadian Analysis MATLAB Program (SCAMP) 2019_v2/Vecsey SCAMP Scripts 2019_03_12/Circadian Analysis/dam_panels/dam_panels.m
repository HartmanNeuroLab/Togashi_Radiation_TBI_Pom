function [px,ri,rs]=dam_panels(o,wells,plotrows,row,selectedAnalysis,groupname,par)
%DAM_PANELS   Row of panels with various analysis for dam data
% dam_panels(o,i,plotrows,row,par)
%
% This function is usually called automatically from dam_analyze
% but can be used standalone also, to look at one fly or to 
% average a group of flies together. 
%
% Inputs: 
% o - Variable with dam information (see dam_load).
% i - Number of well within o that's to be analyzed.
%     If a list of wells, an average will be taken.
%     (default: all of the wells in o). 
%
% plotrows,row: total rows in the plot, and number of row
% where the current panels will go (used when called from
% dam_analyze). Use 1,1 to generate a one-row graph. 
%
% par: Block of parameters (as in par=dam_panels_par)
% (enter dam_panels_par to see the defaults).
% par.lopass: Cutoff (hours) for lo-pass filter 
% par.hipass: Cutoff (hours) for hi-pass filter
% (set par.lopass and par.hipass to 0 for no filtering)
% plotcols: List of types of panels you want here.
% Panels available are: 
%     'acto'  - actogram (see actogram)
%     'histo' - histogram (see dam_hist)
%     'auto'  - autocorrelation (see autoco)
%     'mesa'  - mesa (see mesaplot)
%     'flyp'  - fly plot (see flyplot)
%     'flyf'  - filtered fly plot (same as flyp but after
%               lopass/hipass have been applied. This data
%               is the input to auto and mesa). 
%     'pgram' - periodogram (see dam_pgram)
%
% selectedAnalysis: which of the panels above have been chosen for graphing
% groupname: name of group whose data is being analyzed
% par.dam_hist_par: Histogram parameters (see dam_hist)
% par.peakRange: Range of rhythm (see mesaplot)
% par.mesaFunct, par.mesaOrder: see per_mesa. 
% par.cutoff: Actogram cutoff (see actogram).
% par.truncate: Time truncation, in bins (see dam_truncate)
%
% example: o=dam_load('E21');p=dam_panels_par;
%          p.lopass=0;dam_panels(o,1:8,1,1,p);

%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (C)Jeffrey Hall Lab, Brandeis University.             %%
% Use and distribution of this software is free for academic      %%
% purposes only, provided this copyright notice is not removed.   %%
% Not for commercial use.                                         %%
% Unless by explicit permission from the copyright holder.        %%
% Mailing address:                                                %%
% Jeff Hall Lab, Kalman Bldg, Brandeis Univ, Waltham MA 02454 USA %%
% Email: hall@brandeis.edu                                        %%
% Edited 2012 by Christopher G. Vecsey, Leslie Griffith Lab       %%
%%(C)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
px=[];
ri=[];
rs=[];

if nargin<2
  wells=1:size(o.data,2);
end
if nargin<3
  plotrows=1;
end
if nargin<4
  row=1;
end  
if nargin<7  %This gets called because only 6 arguments are provided in SCAMP
  par=dam_panels_par(selectedAnalysis);
end
if ~isempty (par.truncate)   %This does not get called in current arrangement
  o=dam_truncate(par.truncate(1),par.truncate(2),'bins');
end
row=row-1;
plotcols=length(par.plotcols);
%[f,x,first]=dam_cleanup(o.data(:,i),o.start,o.int,1);
f=o.f(:,wells);
x=o.x;
meanf=mean(f,2);
if par.lopass>0 || par.hipass>0
  filterf=butt_filter(meanf,par.lopass/o.int*60,par.hipass/o.int*60);
else
  filterf=meanf;
end
%if length(i)>1
%  f=mean(f,2);
%end

%if isempty(o.daylight) | isempty(o.daylight{i(1)}) 
%  l=[];
%else
%  l=o.daylight{i(1)}.l;
%  if ~isempty(l)
%    l=l(first:length(x)-(1-first));
%  end
%end
l=o.lights;

% first plot: raw data
for colno=1:plotcols
  fprintf('.');
  subplot(plotrows,plotcols,(row*plotcols)+colno)
  %dam_flyplot(f,x,l);
  what=par.plotcols{colno};
% This doesn't seem to be used...   allthings={'actogram','flyplot','histogram','autocorrelation','mesa','pgram'};
  switch lower(what)
      
   case 'actogram'  %2-20-19: Original 2nd input was "x(1)" but I changed to "0" so actogram always starts from 0 instead of whatever actual time of day was used as CT0
    actogram(meanf,0,o.int,2,l);
    thistitle='Actogram';
    
    
   case 'flyplot'
    flyplot(f,x(1),o.int,l);
    ylim=[min(f),max(f)];
    if ylim(1)>=0
      ylim(1)=-10;
    end
    if (ylim(2)<200)
      ylim(2)=200;
    end
    %set(gca,'ylim');
    thistitle='Activity';
    
     
   case 'filtered flyplot'
    flyplot(filterf,x(1),o.int,l);
    ylim=[min(f),max(f)];
    if ylim(1)>=0
      ylim(1)=-10;
    end
    if (ylim(2)<200)
      ylim(2)=200;
    end
    %set(gca,'ylim');
    thistitle=sprintf('Activity (lopass=%d hipass=%dh)',par.lopass,par.hipass);
    
    
   case 'histogram'
    if isempty(par.dam_hist_par)
      par.hist=dam_hist_par;
      %par.hist.firstHour=floor(x(1))*100;
      par.hist.firstHour=x(1);
      par.hist.barSize=60;
    else
      par.hist=par.dam_hist_par;
    end
    par.hist.int=o.int;
    dam_hist(o,wells,par.hist);
    %thistitle=sprintf('Average Activity (mean=%f)',mean(f));
    thistitle='Average Activity';
    
    
   case 'autocorrelation'
    %[ac,xx,ci]=joelaut(f,2);
    [ac,xx,ci]=autoco(filterf,60/o.int);
    [px,ri,rs]=acplot(ac,xx,ci,(par.acPeak-1)*24+par.peakRange);
    thistitle='Autocorrelation';
    
    
   case 'mesa'
    if isfield(par,'dontfilterMESA') && (par.dontfilterMESA==1)
      mesaf=meanf;
    else
      mesaf=filterf;
    end
    rhythm=mesaplot(mesaf,o.int,par.peakRange,par.mesaFunct,par.mesaOrder);
    thistitle='MESA';

    
   case 'periodogram'
    pgram(filterf,0,0,0,o.int,1);
    thistitle='Periodogram';
    
   otherwise
    fprintf('Error: Panel unknown (%s)\n',what);
    fprintf('Known panels are:\n');
    fprintf('actogram flyplot histogram autoco mesa pgram\n');
    thistitle='';
  end
    if (row> 0) 
      title('');
    else
      title(thistitle);
    end

    if colno==1
        % Basically, if you're graphing group data, the ylabel will be
        % the group name (unless there's only 1 animal in the group).
        % Otherwise, the ylabel will be the name of the channel (when graphing individual data, e.g.).
        if length(wells)>1
        ylabel(groupname)
        else
            ylabel(o.names{wells});
        end
        %Following code used to make the ylabel for group data include the
        %first and last channel name from that group, which seemed less
        %useful than having the group name associated with its data, so I
        %changed it to the system just above.
        
%       if length(wells)>1
%  	ylabel(sprintf('%s...%s',o.names{wells(1)},o.names{wells(length(wells))}));
%       else
% 	ylabel(o.names{wells});
%       end
%     else
%       ylabel('');
    end
    
    if (row+1 < plotrows)
      xlabel('');
    end
end
